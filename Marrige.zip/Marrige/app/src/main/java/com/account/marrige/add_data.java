package com.account.marrige;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class add_data extends AppCompatActivity  implements View.OnClickListener{
  EditText name,birthdate,birthplace,height,occupation,education,father_name,father_occupation,
          contact_no,mother_name,number_of_sister,full_adderss ;
  Button next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        instantiate();
        next.setOnClickListener(this);

    }

    public boolean validate(){
        if(name.getText().toString().isEmpty()){
            name.setError("please Fill Name");
            name.requestFocus();
            return false;
        }
        if(birthdate.getText().toString().isEmpty()){
            birthdate.setError("please Fill Birthdate");
            birthdate.requestFocus();
            return false;
        } if(birthplace.getText().toString().isEmpty()){
            birthplace.setError("please Fill BirthPlace");
            birthplace.requestFocus();
            return false;
        } if(height.getText().toString().isEmpty()){
            height.setError("please Fill Height");
            height.requestFocus();
            return false;
        } if(occupation.getText().toString().isEmpty()){
            occupation.setError("please Fill Your Occupation");
            occupation.requestFocus();
            return false;
        } if(education.getText().toString().isEmpty()){
            education.setError("please Fill Education");
            education.requestFocus();
            return false;
        } if(father_name.getText().toString().isEmpty()){
            father_name.setError("please Fill Father Name");
            father_name.requestFocus();
            return false;
        } if(father_occupation.getText().toString().isEmpty()){
            father_occupation.setError("please Fill Father Occupation");
            father_occupation.requestFocus();
            return false;
        } if(contact_no.getText().toString().isEmpty()){
            contact_no.setError("please Fill Contact Details");
            contact_no.requestFocus();
            return false;
        } if(mother_name.getText().toString().isEmpty()){
            mother_name.setError("please Fill Mother Name");
            mother_name.requestFocus();
            return false;
        } if(number_of_sister.getText().toString().isEmpty()){
            number_of_sister.setError("please Fill ");
            number_of_sister.requestFocus();
            return false;
        } if(full_adderss.getText().toString().isEmpty()){
            full_adderss.setError("please Fill Address");
            full_adderss.requestFocus();
            return false;
        }
        return true;
    }
    public void instantiate(){
        name = findViewById(R.id.view_add_name);
        birthdate = findViewById(R.id.view_add_birthdate);
        birthplace = findViewById(R.id.view_add_birthplace);
        height = findViewById(R.id.view_add_height);
        occupation = findViewById(R.id.view_add_occupation);
        education = findViewById(R.id.view_add_education);
        father_name = findViewById(R.id.view_add_father_name);
        father_occupation = findViewById(R.id.view_add_father_occupation);
        contact_no = findViewById(R.id.view_add_contact);
        mother_name = findViewById(R.id.view_add_mother_name);
        number_of_sister = findViewById(R.id.view_add_no_of_sister);
        full_adderss = findViewById(R.id.view_add_full_address);
        next = findViewById(R.id.next_button);
    }

    @Override
    public void onClick(View v) {
        if(validate()){
            //Execution Code for Filled Data
        }
        else{
              
        }
    }
}